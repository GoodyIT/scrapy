import scrapy
import json
import csv
from scrapy.spiders import Spider
from scrapy.http import FormRequest
from scrapy.http import Request
from scrapy.selector import HtmlXPathSelector
from chainxy.items import ChainItem

import pdb
from scrapy.http import HtmlResponse
from lxml import html
from lxml.html import fromstring
from geopy.geocoders import Nominatim

class Mattressfirm(scrapy.Spider):
    name = "mattressfirm"

    domain = "http://en.store.dior.com"
    start_urls = ["https://maps.mattressfirm.com/api/getAutocompleteData"]
    store_link = "https://maps.mattressfirm.com/api/getAsyncLocations?template=searchmap&level=search&radius=100&search=%s"

    def __init__(self):
        self.geolocator = Nominatim()

    # calculate number of pages
    def parse(self, response):
        data=json.loads(response.body)
        zipcode_list = data['data'][1829:]

        for zipCode in zipcode_list:
            url = self.store_link % zipCode
            request = scrapy.Request(url=url, callback=self.parse_store_contents)

            yield request
            return

    # pare store detail page
    def parse_store_contents(self, response):   
        store_lists =json.loads(response.body)['markers']
        store_id_list = html.fromstring(json.loads(response.body)['maplist']).xpath('//script[contains(., "store-id")]/text()')
        
        for index in range(0, len(store_id_list)):       
            temp = {}
            temp['store_number'] = store_id_list[index].split("store-id")[1].split("};")[0][5:-5]
            if temp["storeNumber"] in self.store_numbers:
                continue

            self.store_numbers.append(temp["storeNumber"])
            
            store = store_lists[index]    
            info =  html.fromstring(store['info']).xpath('//div[@class="city-tlsmap-box"]')[0];
            
            temp['store_name'] = info.xpath('//div[@class="tlsmap-right"]/div[@id="rls-list-info"]/a/div/text()')[0]
            address = info.xpath('//div[@class="tlsmap-right"]/div[@id="rls-list-info"]/div[@class="addr"]/text()')
            temp['address'] = address[0]
            temp['address2'] = ''
            try:
                temp['address2'] = address[1]
            except:
                pass
            temp['phone_number'] = info.xpath('//div[@class="tlsmap-right"]/div[@id="rls-list-info"]/div[@class="phone"]/text()')[0]
            temp['latitude'] = self.validate(store, "lat")
            temp['longitude'] = self.validate(store, "lng")
            
            location = self.geolocator.reverse("%s, %s" % (str(temp['latitude']), str(temp['longitude'])))
            temp['city'] = ''
            try:
                temp['city'] = location.raw["address"]["city"]
            except:
                if 'town' in location.raw["address"]:
                    temp['city'] = location.raw["address"]["town"]

            temp['state'] = location.raw["address"]["state"] if "state" in location.raw["address"] else ""   

            self.validate(location.raw["address"], "postcode")    
            temp['country'] = location.raw["address"]["country_code"].upper()

            link = info.xpath('//div[@class="tlsmap-right"]/div[@id="rls-list-info"]/div[@class="lnks"]/a')[0].xpath('@href')[0]

            # pdb.set_trace();
            
            request = scrapy.Request(url=link, callback=self.parse_hours)
            request.meta['store_number'] = temp['store_number'];
            request.meta['store_name'] = temp['store_name'];
            request.meta['address'] = temp['address'];
            request.meta['address2'] = temp['address2'];
            request.meta['phone_number'] = temp['phone_number']
            request.meta['latitude'] = temp['latitude']
            request.meta['longitude'] = temp['longitude']
            request.meta['city'] = temp['city'];
            request.meta['state'] = temp['state'];
            request.meta['country'] = temp['country']

            yield request
            return

    def parse_hours(self, response):
        
        item = ChainItem()
        item['store_number'] = response.meta['store_number'];
        item['store_name'] = response.meta['store_name'];
        item['address'] = response.meta['address'];
        item['address2'] = response.meta['address2'];
        item['phone_number'] = response.meta['phone_number']
        item['latitude'] = response.meta['latitude']
        item['longitude'] = response.meta['longitude']
        item['city'] = response.meta['city'];
        item['state'] = response.meta['state'];
        item['country'] = response.meta['country']
        rest_info = response.xpath('//div[@id="rls-info-wrap-top"]')
        info_hours = rest_info.xpath('//div[@id="hoursContainer"]/span/div[@class="hours"]/div[@class="day-hour-row"]').extract()
        pdb.set_trace();
        hours = []
        for hour in info_hours:
            hours.append(fromstring(hour).xpath('//meta/@content')[0])


        item['store_hours'] = "; ".join(hours)
        
        
        #item['store_type'] = info_json["@type"]
        item['other_fields'] = ''
        item['coming_soon'] = '0'

        yield item;

    def validate(self, store, property):
        if property in store:
            return store[property]
        return ""


        

